Instructions for installing the Flash Builder 4 Test Drive server files

Note: The Test Drive database is adapted from the MySQL sample Employees database. The database is distributed under the Creative Commons license. The
Creative Commons license is available at: http://creativecommons.org/licenses/by-sa/3.0/. The original, unaltered database is available at: http://dev.mysql.com/doc/employee/en/employee.html.



PHP
--------------------------
1. Unzip the testdrive_setup_PHP.zip. It contains a Database and a Test Drive folder.


2. Create the testdrive_db database on your MySQL installation using the testdrive_db.sql file located in the Database folder. If you do not have permissions to create a database, use the testdrive_table.sql file instead to create two tables in an existing database. After the database is created, set user privileges for it.


3. Move the TestDrive folder, which contains the PHP service file, to your PHP server.


4. Open /TestDrive/services/EmployeeService.php in an editor and change the username, password, server, port, and databasename properties to the correct values for your setup. This class file contains the methods you will call from your Flex application to retrieve, add, update, and delete data.


ColdFusion
--------------------------
1. Unzip the testdrive_setup_CF.zip. It contains a CAR file.


2. In the ColdFusion Administrator, navigate to Packaging & Deployment and deploy the CAR file. In the Deploy Wizard, change the deploy locations to reflect the locations of the db and wwwroot folders on your server. After deploying, check that you have a new data source called testdrive_db and a new folder in wwwroot called TestDrive. If your datasource verification fails, delete the datasource and recreate it: test-drive_db, Apache Derby Embedded, and point to the /ColdFusion/db/testdrive database just installed.


3. Open /ColdFusion/wwwroot/TestDrive/services/EmployeeService.cfc in an editor. This class file contains the methods you will call from your Flex application to retrieve, add, update, and delete data. Note that the methods have the access argument set to remote so that they can be called from a Flex application.

4. Open /ColdFusion9/wwwroot/WEB-INF/flex/services-config.xml in an editor. This file is used when calls are made to the server from your application. Locate the <property-case> tag and change all three values to true as shown below. Restart the ColdFusion server.
  
<property-case>      
   <!-- cfc property names -->     
   <force-cfc-lowercase>true</force-cfc-lowercase>     
   <!-- Query column names -->     
   <force-query-lowercase>true</force-query-lowercase>     
   <!-- struct keys -->    
   <force-struct-lowercase>true</force-struct-lowercase> 
</property-case> 

Note: If you are using an earlier version of ColdFusion, your configuration file may not have these tags and you will need to add them. See the documentation on using Flash Remoting with your particular server. 


Java

--------------------------
1. Unzip the testdrive_setup_JAVA.zip. It contains a WAR file for a web application called testdrive.


2. Deploy the WAR file to your web server. It contains the Java classes, an Apache Derby embedded database, and BlazeDS 4 files.

3. Open /{your server wepapps folder}/testdrive/WEB-INF/src/services/EmployeeService.java in an editor. This class file contains the methods you will call from your Flex application to retrieve, add, update, and delete data. 


4. Open /WEB-INF/flex/remoting-config.xml in an editor. This file is used when calls are made to the server from your application. Notice the definition for the destination called employeeService which points to the services.EmployeeService class.
